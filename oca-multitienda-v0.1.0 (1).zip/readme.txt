=== OCA e-Pak Multitienda (Woo + Dokan) ===
Contributors: softwaremakers
Tags: woocommerce, dokan, shipping, oca, epak
Requires at least: 6.5
Tested up to: 6.6
Requires PHP: 8.1
Stable tag: 0.1.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Bootstrap del plugin para integración OCA e-Pak en contexto multitienda (WooCommerce + Dokan). Etapa 0.
